/**
 * Universal Navigation System
 * Automatically injects navigation into pages that don't have it
 * Provides consistent navigation across all user roles and pages
 */

class UniversalNavigation {
  constructor() {
    this.currentUser = this.getCurrentUser();
    this.currentRole = this.currentUser?.role || 'guest';
    this.currentPath = window.location.pathname;
    this.init();
  }

  getCurrentUser() {
    try {
      const token = localStorage.getItem('token');
      if (!token) return null;
      
      const user = localStorage.getItem('user');
      return user ? JSON.parse(user) : null;
    } catch {
      return null;
    }
  }

  isAuthenticated() {
    return !!localStorage.getItem('token') && !!this.currentUser;
  }

  init() {
    // Only inject if no navigation exists
    if (!this.hasExistingNavigation()) {
      this.injectNavigation();
    }
    this.setupEventListeners();
  }

  hasExistingNavigation() {
    return !!(
      document.querySelector('nav') ||
      document.querySelector('.navigation') ||
      document.querySelector('#navigation') ||
      document.querySelector('[data-navigation]') ||
      document.querySelector('.navbar') ||
      document.querySelector('header nav')
    );
  }

  injectNavigation() {
    const nav = this.createNavigation();
    
    // Insert navigation at the top of the page
    const existingHeader = document.querySelector('header');
    if (existingHeader) {
      existingHeader.parentNode.insertBefore(nav, existingHeader);
    } else {
      document.body.insertBefore(nav, document.body.firstChild);
    }

    // Adjust body padding to account for fixed navigation
    document.body.style.paddingTop = '80px';
  }

  createNavigation() {
    const nav = document.createElement('nav');
    nav.className = 'universal-nav fixed top-0 left-0 w-full bg-white shadow-lg border-b border-gray-200 z-50';
    nav.innerHTML = this.getNavigationHTML();
    return nav;
  }

  getNavigationHTML() {
    const logoPath = this.getLogoPath();
    const navItems = this.getNavigationItems();
    
    return `
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between items-center h-16">
          <!-- Logo -->
          <div class="flex items-center">
            <a href="/" class="flex items-center space-x-3">
              <img src="${logoPath}" alt="ADD Physical Products" class="h-10 w-10 rounded-lg">
              <span class="font-bold text-xl text-gray-900">ADD Physical Products</span>
            </a>
          </div>

          <!-- Desktop Navigation -->
          <div class="hidden md:flex items-center space-x-6">
            ${navItems.map(item => `
              <a href="${item.href}" class="nav-link text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${item.active ? 'bg-blue-100 text-blue-700' : ''}">
                ${item.icon ? `<i class="${item.icon} mr-2"></i>` : ''}${item.label}
              </a>
            `).join('')}
            
            ${this.isAuthenticated() ? this.getAuthenticatedMenu() : this.getGuestMenu()}
          </div>

          <!-- Mobile menu button -->
          <div class="md:hidden">
            <button id="mobile-menu-btn" class="text-gray-700 hover:text-blue-600 focus:outline-none focus:text-blue-600" onclick="showNotification('Feature in development', 'info')">
              svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
              </svg>
            </button>
          </div>
        </div>

        <!-- Mobile Navigation -->
        <div id="mobile-menu" class="md:hidden hidden">
          <div class="px-2 pt-2 pb-3 space-y-1 bg-white border-t border-gray-200">
            ${navItems.map(item => `
              <a href="${item.href}" class="block px-3 py-2 text-gray-700 hover:text-blue-600 hover:bg-gray-50 rounded-md text-base font-medium ${item.active ? 'bg-blue-100 text-blue-700' : ''}">
                ${item.icon ? `<i class="${item.icon} mr-2"></i>` : ''}${item.label}
              </a>
            `).join('')}
            
            <div class="border-t border-gray-200 pt-2">
              ${this.isAuthenticated() ? this.getMobileAuthenticatedMenu() : this.getMobileGuestMenu()}
            </div>
          </div>
        </div>
      </div>
    `;
  }

  getLogoPath() {
    // Try different possible logo paths
    const possiblePaths = [
      '/public/images/logo.png',
      '/images/logo.png',
      '/assets/logo.png',
      '/logo.png'
    ];
    
    return possiblePaths[0]; // Default to first path
  }

  getNavigationItems() {
    const basePath = this.getBasePath();
    
    switch (this.currentRole) {
      case 'admin':
        return [
          { label: 'Dashboard', href: '/admin/dashboard.html', icon: 'fas fa-tachometer-alt' },
          { label: 'Users', href: '/admin/user-management.html', icon: 'fas fa-users' },
          { label: 'Products', href: '/admin/products.html', icon: 'fas fa-box' },
          { label: 'Orders', href: '/admin/orders.html', icon: 'fas fa-shopping-cart' },
          { label: 'Analytics', href: '/admin/analytics.html', icon: 'fas fa-chart-bar' }
        ];
      
      case 'seller':
        return [
          { label: 'Dashboard', href: '/seller/dashboard.html', icon: 'fas fa-tachometer-alt' },
          { label: 'Products', href: '/seller/products.html', icon: 'fas fa-box' },
          { label: 'Orders', href: '/seller/orders.html', icon: 'fas fa-shopping-cart' },
          { label: 'Add Product', href: '/seller/add-product.html', icon: 'fas fa-plus' },
          { label: 'Analytics', href: '/seller/analytics.html', icon: 'fas fa-chart-bar' }
        ];
      
      case 'buyer':
        return [
          { label: 'Home', href: '/', icon: 'fas fa-home' },
          { label: 'Products', href: '/public/products.html', icon: 'fas fa-box' },
          { label: 'Categories', href: '/public/categories.html', icon: 'fas fa-th-large' },
          { label: 'Cart', href: '/buyer/cart.html', icon: 'fas fa-shopping-cart' },
          { label: 'Orders', href: '/buyer/orders.html', icon: 'fas fa-list' }
        ];
      
      case 'agent':
        return [
          { label: 'Dashboard', href: '/agent/dashboard.html', icon: 'fas fa-tachometer-alt' },
          { label: 'Orders', href: '/agent/orders.html', icon: 'fas fa-truck' },
          { label: 'Deliveries', href: '/agent/deliveries.html', icon: 'fas fa-shipping-fast' },
          { label: 'Earnings', href: '/agent/earnings.html', icon: 'fas fa-dollar-sign' }
        ];
      
      default: // guest
        return [
          { label: 'Home', href: '/', icon: 'fas fa-home' },
          { label: 'Products', href: '/public/products.html', icon: 'fas fa-box' },
          { label: 'Categories', href: '/public/categories.html', icon: 'fas fa-th-large' },
          { label: 'About', href: '/public/about.html', icon: 'fas fa-info-circle' }
        ];
    }
  }

  getBasePath() {
    const path = this.currentPath;
    if (path.includes('/admin/')) return '/admin';
    if (path.includes('/seller/')) return '/seller';
    if (path.includes('/buyer/')) return '/buyer';
    if (path.includes('/agent/')) return '/agent';
    return '/public';
  }

  getAuthenticatedMenu() {
    return `
      <div class="relative">
        <button id="user-menu-btn" class="flex items-center space-x-2 text-gray-700 hover:text-blue-600 focus:outline-none" onclick="showNotification('Feature in development', 'info')">
          <div class="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
            <span class="text-white text-sm font-medium">${this.currentUser?.name?.charAt(0)?.toUpperCase() || 'U'}</span>
          </div>
          <span class="text-sm font-medium">${this.currentUser?.name || 'User'}</span>
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
          </svg>
        </button>
        
        <div id="user-dropdown" class="hidden absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50">
          <a href="/${this.currentRole}/profile.html" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
            <i class="fas fa-user mr-2"></i>Profile
          </a>
          <a href="/${this.currentRole}/settings.html" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
            <i class="fas fa-cog mr-2"></i>Settings
          </a>
          <div class="border-t border-gray-100"></div>
          <button onclick="logout()" class="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
            <i class="fas fa-sign-out-alt mr-2"></i>Logout
          </button>
        </div>
      </div>
    `;
  }

  getGuestMenu() {
    return `
      <div class="flex items-center space-x-4">
        <a href="/auth/auth-buyer.html" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">
          Login
        </a>
        <a href="/auth/auth-buyer.html" class="bg-blue-600 text-white hover:bg-blue-700 px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200">
          Sign Up
        </a>
      </div>
    `;
  }

  getMobileAuthenticatedMenu() {
    return `
      <a href="/${this.currentRole}/profile.html" class="block px-3 py-2 text-gray-700 hover:text-blue-600 hover:bg-gray-50 rounded-md text-base font-medium">
        <i class="fas fa-user mr-2"></i>Profile
      </a>
      <a href="/${this.currentRole}/settings.html" class="block px-3 py-2 text-gray-700 hover:text-blue-600 hover:bg-gray-50 rounded-md text-base font-medium">
        <i class="fas fa-cog mr-2"></i>Settings
      </a>
      <button onclick="logout()" class="block w-full text-left px-3 py-2 text-gray-700 hover:text-blue-600 hover:bg-gray-50 rounded-md text-base font-medium">
        <i class="fas fa-sign-out-alt mr-2"></i>Logout
      </button>
    `;
  }

  getMobileGuestMenu() {
    return `
      <a href="/auth/auth-buyer.html" class="block px-3 py-2 text-gray-700 hover:text-blue-600 hover:bg-gray-50 rounded-md text-base font-medium">
        Login
      </a>
      <a href="/auth/auth-buyer.html" class="block px-3 py-2 bg-blue-600 text-white hover:bg-blue-700 rounded-md text-base font-medium">
        Sign Up
      </a>
    `;
  }

  setupEventListeners() {
    // Mobile menu toggle
    document.addEventListener('click', (e) => {
      if (e.target.closest('#mobile-menu-btn')) {
        const mobileMenu = document.getElementById('mobile-menu');
        mobileMenu.classList.toggle('hidden');
      }
      
      // User dropdown toggle
      if (e.target.closest('#user-menu-btn')) {
        const dropdown = document.getElementById('user-dropdown');
        dropdown.classList.toggle('hidden');
      }
      
      // Close dropdowns when clicking outside
      if (!e.target.closest('#user-menu-btn') && !e.target.closest('#user-dropdown')) {
        const dropdown = document.getElementById('user-dropdown');
        if (dropdown) dropdown.classList.add('hidden');
      }
    });

    // Mark current page as active
    this.markActivePage();
  }

  markActivePage() {
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
      if (link.getAttribute('href') === currentPath) {
        link.classList.add('bg-blue-100', 'text-blue-700');
      }
    });
  }
}

// Global logout function
window.logout = function() {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  window.location.href = '/';
};

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    new UniversalNavigation();
  });
} else {
  new UniversalNavigation();
}

// Add required CSS
const style = document.createElement('style');
style.textContent = `
  .universal-nav {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  }
  
  .nav-link {
    transition: all 0.2s ease-in-out;
  }
  
  .nav-link:hover {
    transform: translateY(-1px);
  }
  
  #user-dropdown {
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    border: 1px solid rgba(0, 0, 0, 0.05);
  }
  
  @media (max-width: 768px) {
    body {
      padding-top: 64px !important;
    }
  }
`;
document.head.appendChild(style);

// Add Font Awesome if not already present
if (!document.querySelector('link[href*="font-awesome"]') && !document.querySelector('link[href*="fontawesome"]')) {
  const fontAwesome = document.createElement('link');
  fontAwesome.rel = 'stylesheet';
  fontAwesome.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css';
  document.head.appendChild(fontAwesome);
}