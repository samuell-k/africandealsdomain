/**
 * Enhanced Mode Switcher Component
 * Allows users to switch between Physical Products Marketplace and Local Market modes
 * Ensures proper navigation to dedicated pages for each marketplace
 */

class ModeSwitcher {
  constructor() {
    this.currentMode = this.getCurrentMode();
    this.userRole = this.getUserRole();
    this.init();
  }

  init() {
    this.createSwitcher();
    this.setupEventListeners();
    this.updateUI();
    this.preserveUserSession();
  }

  getCurrentMode() {
    // Determine current mode based on URL path
    const path = window.location.pathname;
    if (path.includes('/grocery/') || path.includes('local-market')) {
      return 'local-market';
    }
    return 'marketplace';
  }

  getUserRole() {
    try {
      const user = JSON.parse(localStorage.getItem('user') || '{}');
      return user.role || 'guest';
    } catch {
      return 'guest';
    }
  }

  createSwitcher() {
    // Find existing mode switch container or create one
    let container = document.querySelector('[data-mode-switch]');
    
    if (!container) {
      // Create container if it doesn't exist
      container = document.createElement('div');
      container.setAttribute('data-mode-switch', '');
      container.className = 'mode-switcher-container';
      
      // Try to insert in navigation or create floating button
      const nav = document.querySelector('nav');
      const header = document.querySelector('header');
      
      if (nav) {
        // Try to find a good spot in navigation
        const navContainer = nav.querySelector('.flex') || nav.querySelector('div') || nav;
        navContainer.appendChild(container);
      } else if (header) {
        header.appendChild(container);
      } else {
        // Create floating button as fallback
        container.className += ' fixed top-4 right-4 z-50';
        document.body.appendChild(container);
      }
    }

    // Create the switcher HTML with improved styling and visibility
    container.innerHTML = `
      <div class="mode-switcher bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">
        <div class="flex">
          <button 
            data-mode="marketplace" 
            class="mode-option px-4 py-3 text-sm font-semibold transition-all duration-300 flex items-center gap-2 ${this.currentMode === 'marketplace' ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-md' : 'text-gray-700 hover:bg-blue-50 hover:text-blue-600'}"
            title="Switch to Physical Products Marketplace"
          >
            <span class="text-lg">📦</span>
            <span class="hidden sm:inline">Products</span>
          </button>
          <button 
            data-mode="local-market" 
            class="mode-option px-4 py-3 text-sm font-semibold transition-all duration-300 flex items-center gap-2 ${this.currentMode === 'local-market' ? 'bg-gradient-to-r from-green-500 to-green-600 text-white shadow-md' : 'text-gray-700 hover:bg-green-50 hover:text-green-600'}"
            title="Switch to Local Market Fast Delivery"
          >
            <span class="text-lg">🛒</span>
            <span class="hidden sm:inline">Local Market</span>
          </button>
        </div>
      </div>
    `;
  }

  setupEventListeners() {
    document.querySelectorAll('.mode-option').forEach(button => {
      button.addEventListener('click', (e) => {
        const targetMode = e.currentTarget.dataset.mode;
        this.switchMode(targetMode);
      });
    });
  }

  switchMode(targetMode) {
    if (targetMode === this.currentMode) return;

    const currentPath = window.location.pathname;
    let targetPath = this.getTargetPath(targetMode, currentPath);

    // Store mode preference
    localStorage.setItem('preferredMode', targetMode);

    // Show loading indicator
    this.showSwitchingIndicator(targetMode);

    // Navigate to target path
    setTimeout(() => {
      window.location.href = targetPath;
    }, 300);
  }

  getTargetPath(targetMode, currentPath) {
    const role = this.userRole;
    
    if (targetMode === 'local-market') {
      // Switch to Local Market - each role gets its dedicated pages
      if (role === 'buyer' || role === 'guest') {
        if (currentPath === '/' || currentPath === '/public/index.html' || currentPath.includes('/public/')) {
          return '/grocery/local-market-home.html';
        } else if (currentPath.includes('/buyer/buyers-home')) {
          return '/grocery/local-market-home.html';
        } else if (currentPath.includes('/buyer/products') || currentPath.includes('/public/product')) {
          return '/grocery/local-market-products.html';
        } else if (currentPath.includes('/buyer/cart')) {
          return '/grocery/cart.html';
        } else if (currentPath.includes('/buyer/orders')) {
          return '/grocery/grocery-orders.html';
        } else if (currentPath.includes('/buyer/dashboard') || currentPath.includes('/buyer/')) {
          return '/grocery/local-market-home.html';
        } else {
          return '/grocery/local-market-home.html';
        }
      } else if (role === 'seller') {
        if (currentPath.includes('/seller/dashboard')) {
          return '/seller/local-market-dashboard.html';
        } else if (currentPath.includes('/seller/add-product')) {
          return '/seller/add-local-market-product.html';
        } else if (currentPath.includes('/seller/product-list')) {
          return '/seller/local-market-dashboard.html';
        } else {
          return '/seller/local-market-dashboard.html';
        }
      } else if (role === 'agent') {
        return '/agent/local-market-dashboard.html';
      } else if (role === 'admin') {
        return '/admin/local-market-admin.html';
      } else {
        // Guest user
        return '/grocery/local-market-home.html';
      }
    } else {
      // Switch to Physical Products Marketplace
      if (role === 'buyer') {
        if (currentPath.includes('/grocery/local-market-home') || currentPath.includes('/grocery/products')) {
          return '/buyer/buyers-home.html';
        } else if (currentPath.includes('/grocery/cart')) {
          return '/buyer/cart.html';
        } else if (currentPath.includes('/grocery/orders') || currentPath.includes('/grocery/grocery-orders')) {
          return '/buyer/orders.html';
        } else {
          return '/buyer/buyers-home.html';
        }
      } else if (role === 'seller') {
        if (currentPath.includes('/seller/add-grocery-product')) {
          return '/seller/add-product.html';
        } else {
          return '/seller/dashboard.html';
        }
      } else if (role === 'agent') {
        return '/agent/dashboard.html';
      } else if (role === 'admin') {
        return '/admin/dashboard.html';
      } else {
        // Guest user - go to public homepage
        return '/public/index.html';
      }
    }
  }

  preserveUserSession() {
    // Ensure user session is maintained across mode switches
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    
    if (token && user) {
      // Session is valid, no action needed
      return;
    }
    
    // If no session, redirect to appropriate auth page when trying to access protected areas
    const protectedPaths = ['/buyer/', '/seller/', '/agent/', '/admin/'];
    const currentPath = window.location.pathname;
    
    if (protectedPaths.some(path => currentPath.includes(path))) {
      const authPath = this.getAuthPath();
      if (authPath) {
        setTimeout(() => {
          window.location.href = authPath;
        }, 1000);
      }
    }
  }

  getAuthPath() {
    const role = this.userRole;
    switch (role) {
      case 'buyer': return '/auth/auth-buyer.html';
      case 'seller': return '/auth/auth-seller.html';
      case 'agent': return '/auth/auth-agent.html';
      case 'admin': return '/auth/auth-admin.html';
      default: return '/auth/auth-buyer.html';
    }
  }

  showSwitchingIndicator(targetMode) {
    const modeName = targetMode === 'local-market' ? 'Local Market' : 'Marketplace';
    
    // Create temporary indicator
    const indicator = document.createElement('div');
    indicator.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
    indicator.innerHTML = `
      <div class="bg-white rounded-2xl p-6 max-w-sm mx-4 text-center">
        <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-${targetMode === 'local-market' ? 'green' : 'blue'}-500 mx-auto mb-4"></div>
        <p class="text-gray-900 font-medium">Switching to ${modeName}...</p>
      </div>
    `;
    
    document.body.appendChild(indicator);
    
    // Remove after navigation
    setTimeout(() => {
      if (indicator.parentNode) {
        indicator.parentNode.removeChild(indicator);
      }
    }, 2000);
  }

  updateUI() {
    // Update active state with new styling
    document.querySelectorAll('.mode-option').forEach(button => {
      const mode = button.dataset.mode;
      if (mode === this.currentMode) {
        // Remove inactive styles
        button.classList.remove('text-gray-700', 'hover:bg-blue-50', 'hover:bg-green-50', 'hover:text-blue-600', 'hover:text-green-600');
        // Add active styles
        if (mode === 'local-market') {
          button.classList.add('bg-gradient-to-r', 'from-green-500', 'to-green-600', 'text-white', 'shadow-md');
        } else {
          button.classList.add('bg-gradient-to-r', 'from-blue-500', 'to-blue-600', 'text-white', 'shadow-md');
        }
      } else {
        // Remove active styles
        button.classList.remove('bg-gradient-to-r', 'from-green-500', 'to-green-600', 'from-blue-500', 'to-blue-600', 'text-white', 'shadow-md');
        // Add inactive styles
        button.classList.add('text-gray-700');
        if (mode === 'local-market') {
          button.classList.add('hover:bg-green-50', 'hover:text-green-600');
        } else {
          button.classList.add('hover:bg-blue-50', 'hover:text-blue-600');
        }
      }
    });

    // Update page indicators
    this.updatePageIndicators();
  }

  updatePageIndicators() {
    // Add mode indicator to page title or header
    const modeIndicator = document.querySelector('.mode-indicator');
    if (modeIndicator) {
      modeIndicator.textContent = this.currentMode === 'local-market' ? 'Local Market' : 'Marketplace';
    }

    // Update body class for styling
    document.body.classList.remove('marketplace-mode', 'local-market-mode');
    document.body.classList.add(`${this.currentMode}-mode`);
  }

  // Static method to initialize mode switcher
  static init() {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        new ModeSwitcher();
      });
    } else {
      new ModeSwitcher();
    }
  }
}

// Auto-initialize if script is loaded
if (typeof window !== 'undefined') {
  ModeSwitcher.init();
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ModeSwitcher;
}